package handler;

import com.google.gson.Gson;

public class GsonTool {

  public static final Gson gson = new Gson();

}
